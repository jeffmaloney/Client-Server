This repository has a webpage that interacts with a local server over a REST API.
These API perform simple string operations.

To run the webpage in your browser:
    click and drag index.html into the address bar.

To run the server app.js:
Move the 'assign3' folder to where it can be run by Node.js.
For me, with a MEAN stack, that is here:
C:\Bitnami\meanstack-4.4.3-0\apache2\htdocs\assign3.
Open in VSCode... Open a terminal window in assign3.
In terminal type > node app.js
Keep this terminal window open as long as you want the server running.


Download and install MEAN Stack:
choose one of the below:
https://bitnami.com/redirect/to/1270603/bitnami-meanstack-4.4.3-0-windows-x64-installer.exe
https://bitnami.com/redirect/to/1507975/bitnami-meanstack-4.4.6-2-r02-osx-x86_64-vm.dmg
https://bitnami.com/redirect/to/1270602/bitnami-meanstack-4.4.3-0-linux-x64-installer.run

