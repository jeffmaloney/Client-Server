// Rest API that runs on Node.js.
// These APIs do simple operations on strings

//import required module
var express = require("express");
var app = express();

//this prevents CORS error from occuring in the browser upon requests
app.all('/*', (req,res,next) =>{
    res.header('Access-Control-Allow-Origin', '*');
    next();
});
//define a route using a callback function tha will be invoked
// when the user makes a HTTP request to the root of the folder (URL)
// display some info about the service
app.get('/', function(req,res){
    res.status(200);
    res.send("<h1>This REST service will operate on strings</h1>");
    console.log("a request has been processed in root");
});

//Endpoint 1: concatenate the 2 input strings
//return json of the resulting string
app.get('/cat/:str1/:str2',function(req,res){
    const str1 = req.params.str1;
    const str2 = req.params.str2;
    var result = str1 + str2;
    res.status(200);
    res.json({"result": result});
    console.log("request to /cat/str1/str2");
    
});
//Endpoint 2: reverse the input string
//return json of the reversed string.
app.get('/rev/:str',function(req,res){
    const str = req.params.str;
    var result = "";
    for(var i = str.length - 1; i >= 0; i--){
        result += str.charAt(i);
    }
    res.status(200);
    res.json({"result": result})
    console.log("request to /rev/:str");
});
//Endpoint 3: turn an string into a palindrome
//return json of the resulting string
app.get('/pal/:str',function(req,res){
    const str = req.params.str;
    var secondHalf = "";
    for(var i = str.length - 1; i >= 0; i--){
        secondHalf += str.charAt(i);
    }
    var result = str + secondHalf;
    res.status(200);
    res.json({"result": result})
    console.log("request to /pal/:str");
});

//Endpoint 4: input a number and a string.
//return json of the string repeated by the number
app.get('/mult/:str/:num',function(req,res){
    var str = req.params.str;
    var num = parseInt(req.params.num);
    var result = "";
    for(var i = 0; i < num; i++){
        result += str;
    }
    res.status(200);
    res.json({"result": result})
    console.log("request to /mult/:str/:num");
});

//enable a port to listen to incoming HTTP requests
app.listen(3000,function(){
    console.log("API version 1.0.0 is running on port 3000");
});
